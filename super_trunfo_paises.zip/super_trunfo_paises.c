
#include <stdio.h>

#define MAX_CARTAS 100

// Estrutura para armazenar os dados da carta
struct Carta {
    char estado[50];
    int codigo;
    char nomeCidade[100];
    long int populacao;
    float pib; // em bilhões
    float area; // em km²
    int pontosTuristicos;

    // Propriedades derivadas
    float densidadePopulacional;
    float pibPerCapita;
};

// Função para calcular os atributos derivados
void calcularAtributos(struct Carta *carta) {
    if (carta->area > 0)
        carta->densidadePopulacional = carta->populacao / carta->area;
    else
        carta->densidadePopulacional = 0;

    if (carta->populacao > 0)
        carta->pibPerCapita = (carta->pib * 1000000000) / carta->populacao;
    else
        carta->pibPerCapita = 0;
}

// Função para cadastrar uma carta
void cadastrarCarta(struct Carta *carta) {
    printf("\n=== Cadastro de Carta ===\n");
    printf("Estado: ");
    scanf(" %[^
]", carta->estado);

    printf("Código da cidade: ");
    scanf("%d", &carta->codigo);

    printf("Nome da cidade: ");
    scanf(" %[^
]", carta->nomeCidade);

    printf("População: ");
    scanf("%ld", &carta->populacao);

    printf("PIB (em bilhões): ");
    scanf("%f", &carta->pib);

    printf("Área (em km²): ");
    scanf("%f", &carta->area);

    printf("Número de pontos turísticos: ");
    scanf("%d", &carta->pontosTuristicos);

    calcularAtributos(carta);

    printf("Carta cadastrada com sucesso!\n");
}

// Função para exibir os dados de uma carta
void exibirCarta(struct Carta carta) {
    printf("\n=== Carta ===\n");
    printf("Estado: %s\n", carta.estado);
    printf("Código: %d\n", carta.codigo);
    printf("Cidade: %s\n", carta.nomeCidade);
    printf("População: %ld\n", carta.populacao);
    printf("PIB: R$ %.2f bilhões\n", carta.pib);
    printf("Área: %.2f km²\n", carta.area);
    printf("Pontos turísticos: %d\n", carta.pontosTuristicos);
    printf("Densidade populacional: %.2f hab/km²\n", carta.densidadePopulacional);
    printf("PIB per capita: R$ %.2f\n", carta.pibPerCapita);
}

int main() {
    struct Carta cartas[MAX_CARTAS];
    int total = 0;
    int opcao;

    do {
        printf("\n--- Super Trunfo de Países ---\n");
        printf("1. Cadastrar nova carta\n");
        printf("2. Exibir todas as cartas\n");
        printf("3. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                if (total < MAX_CARTAS) {
                    cadastrarCarta(&cartas[total]);
                    total++;
                } else {
                    printf("Limite de cartas atingido!\n");
                }
                break;
            case 2:
                for (int i = 0; i < total; i++) {
                    exibirCarta(cartas[i]);
                }
                break;
            case 3:
                printf("Encerrando...\n");
                break;
            default:
                printf("Opção inválida.\n");
        }
    } while (opcao != 3);

    return 0;
}
